// var mymap = L.map('mapid');
// mymap.setView([51.505, -0.09], 13);
// L.tileLayer('http://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
//     attribution: 'Map data © <a href="http://openstreetmap.org">OpenStreetMap</a> contributors',
//     maxZoom: 18,
// }).addTo(mymap);
//
// var marker = L.marker([51.5, -0.09]).addTo(mymap);
//
// var LeafIcon = L.Icon.extend({
//     options: {
//         //shadowUrl: 'leaf-shadow.png',
//         iconSize:     [21, 21],
//         //shadowSize:   [50, 64],
//         iconAnchor:   [21, 21],
//         //shadowAnchor: [4, 62],
//         popupAnchor:  [-10, -21]
//     }
// });
//
// var okIcon = new LeafIcon({iconUrl: '/mavoix-ok.png'});
// var noIcon = new LeafIcon({iconUrl: '/mavoix-no.png'});
//
// L.marker([51.5, -0.09], {icon: okIcon}).addTo(mymap).bindPopup("Le panneau est bon");
